const socket = io({ transports: ['websocket', 'polling'] });

const $ = id => document.getElementById(id);
const lobby = $('lobby');
const call = $('call');
const statusEl = $('status');
const displayNameEl = $('displayName');
const roomInput = $('roomInput');
const remoteVideo = $('remoteVideo');
const localVideo = $('localVideo');
const remotePlaceholder = $('remotePlaceholder');
const roomLabel = $('roomLabel');
const localLabel = $('localLabel');
const remoteLabel = $('remoteLabel');
const networkState = $('networkState');
const networkDot = $('networkDot');
const iceStateEl = $('iceState');
const candidateTypeEl = $('candidateType');
const turnStateEl = $('turnState');
const qualityState = $('qualityState');
const bitrateState = $('bitrateState');
const messagesEl = $('messages');
const chatInput = $('chatInput');
const typingIndicator = $('typingIndicator');
const fileInput = $('fileInput');
const uploadBtn = $('uploadBtn');
const recordAudioBtn = $('recordAudioBtn');
const languageSelect = $('languageSelect');
const unreadBadge = $('unreadBadge');
const notificationsBtn = $('notificationsBtn');
const downloadChatBtn = $('downloadChatBtn');
const toastContainer = $('toastContainer');

let currentRoom = '';
let localName = 'Guest';
let pc = null;
let localStream = null;
let remoteStream = null;
let remoteSocketId = null;
let config = { iceServers: [] };
let turnReady = false;
let remoteCandidateQueue = [];
let pendingRestart = false;
let makingOffer = false;
let ignoreOffer = false;
let isPolite = false;
let screenStream = null;
let screenTrack = null;
let cameraTrack = null;
let audioTrack = null;
let callStartedAt = 0;
let timerHandle = null;
let statsHandle = null;
let lastBytes = 0;
let lastStatsAt = 0;
let typingTimer = null;
let reconnectAttempt = 0;
let mediaRecorder = null;
let audioChunks = [];
let recordingStartedAt = 0;
let recordingTimer = null;
let currentLang = localStorage.getItem('lutsavidcall_lang') || 'ar';
let unreadCount = 0;
let pushRegistration = null;
let pushSubscription = null;
let notificationReady = false;
let audioContext = null;
let lastNotifiedMessageId = '';

const I18N = {
  ar: {
    appName: 'Lutsa vidcall',
    title: 'مكالمات فيديو عبر شبكات مختلفة',
    subtitle: 'اتصال فيديو وصوت مع غرفة دردشة، صور وملفات وصوتيات. صُمم للعمل بين Wi‑Fi و4G/5G باستخدام WebRTC مع STUN/TURN.',
    yourName: 'اسمك',
    namePlaceholder: 'مثال: Ahmed',
    createRoom: 'إنشاء غرفة جديدة',
    joinRoom: 'دخول إلى غرفة',
    roomCode: 'رمز الغرفة',
    roomPlaceholder: 'مثال: A1B2C3D4',
    enter: 'دخول',
    ready: 'جاهز',
    security: '🔒 لا ترسل رمز الغرفة علناً. في الإنتاج استخدم HTTPS وبيانات TURN مؤقتة.',
    room: 'الغرفة',
    waitingPeer: 'بانتظار الطرف الآخر…',
    otherParty: 'الطرف الآخر',
    you: 'أنت',
    voice: '🎙️ صوت',
    noAudio: '🔇 بدون صوت',
    mic: '🎙️ الميكروفون',
    micOff: '🔇 الميكروفون مكتوم',
    camera: '📷 الكاميرا',
    cameraOff: '🚫 الكاميرا متوقفة',
    shareScreen: '🖥️ مشاركة الشاشة',
    stopShare: '🛑 إيقاف مشاركة الشاشة',
    devices: '⚙️ الأجهزة',
    reconnect: '🔄 إعادة الاتصال',
    copyLink: '🔗 نسخ الرابط',
    hangup: '📞 إنهاء',
    devicePanel: 'اختيار الأجهزة',
    camera: 'الكاميرا',
    microphone: 'الميكروفون',
    speaker: 'السماعة',
    deviceNote: 'اختيار السماعة يحتاج دعماً من المتصفح والجهاز. تغيير الكاميرا/الميكروفون يتم أثناء المكالمة.',
    connectionStatus: 'حالة الاتصال',
    ice: 'ICE',
    path: 'المسار',
    turnSession: 'TURN للجلسة',
    turnPreparing: 'جاري تجهيز TURN…',
    turnReady: 'TURN جاهز',
    turnUnavailable: 'TURN غير متاح — سيستمر الاتصال المباشر',
    videoQuality: 'جودة الفيديو',
    bitrate: 'الجودة',
    turnHint: 'وجود TURN مضبوط بشكل صحيح مهم عندما تمنع الشبكة الاتصال المباشر.',
    chatRoom: '💬 غرفة الدردشة',
    typeMessage: 'اكتب رسالة…',
    send: 'إرسال',
    attach: '📎 ملف / صورة',
    audioMessage: '🎙️ إرسال صوتية',
    stopRecording: '⏹️ إيقاف التسجيل',
    recording: 'جارٍ التسجيل',
    uploadPreparing: 'جاري تجهيز الملف…',
    uploading: 'جاري رفع الملف…',
    uploaded: 'تم إرسال الملف.',
    maxFile: 'الحد الأقصى للملف هو {size} MB.',
    fileType: 'نوع الملف غير مسموح.',
    uploadFailed: 'تعذر رفع الملف.',
    fileRequired: 'اختر ملفاً أولاً.',
    audioFailed: 'تعذر تسجيل الصوت. اسمح للمتصفح باستخدام الميكروفون.',
    audioSent: 'تم إرسال الصوتية.',
    audioRecording: 'تسجيل صوتية جديدة',
    noBrowserRecord: 'تسجيل الصوت غير مدعوم في هذا المتصفح.',
    callConnected: 'المكالمة متصلة.',
    preparing: 'جاري إنشاء الاتصال…',
    joined: 'تم الدخول. بانتظار الاتصال…',
    foundPeer: 'تم العثور على الطرف الآخر. بدء المكالمة…',
    roomCreated: 'تم إنشاء الغرفة {room}.',
    shareRoom: 'تم إنشاء الغرفة. أرسل الرابط للطرف الآخر.',
    mediaPreparing: 'جاري تجهيز الكاميرا والميكروفون…',
    permission: 'تعذر الوصول إلى الكاميرا/الميكروفون. اسمح بالصلاحيات ثم أعد المحاولة.',
    https: 'للاتصال من جهاز آخر يجب نشر الموقع عبر HTTPS. localhost فقط يعمل بدون HTTPS.',
    roomFull: 'الغرفة ممتلئة (شخصان فقط).',
    cannotJoin: 'تعذر دخول الغرفة.',
    invalidRoom: 'أدخل رمز الغرفة',
    remoteLeft: 'غادر الطرف الآخر الغرفة',
    leftHint: 'غادر الطرف الآخر. يمكنك مشاركة الرابط مرة أخرى.',
    remoteHangup: 'أنهى الطرف الآخر المكالمة.',
    signalingDown: 'انقطع signaling',
    serverRestored: 'تم استعادة اتصال الخادم.',
    remoteTyping: '{name} يكتب…',
    autoplay: 'اضغط على فيديو الطرف الآخر لتمكين الصوت إذا منع المتصفح التشغيل التلقائي.',
    screenUnsupported: 'مشاركة الشاشة غير مدعومة في هذا المتصفح.',
    screenOn: 'مشاركة الشاشة مفعّلة.',
    cameraBack: 'عادت الكاميرا للمكالمة.',
    cameraChanged: 'تم تغيير الكاميرا.',
    micChanged: 'تم تغيير الميكروفون.',
    micUnsupported: 'تعذر تغيير الميكروفون.',
    cameraUnsupported: 'تعذر تغيير الكاميرا.',
    speakerChanged: 'تم تغيير السماعة.',
    speakerUnsupported: 'تغيير السماعة غير مدعوم في هذا المتصفح.',
    copied: 'تم نسخ رابط الغرفة. أرسله للطرف الآخر.',
    copyPrompt: 'انسخ رابط الغرفة:',
    reconnecting: 'إعادة بناء المسار…',
    disconnected: 'انقطع اتصال الخادم مؤقتاً…',
    unexpected: 'حدث تعارض مؤقت في التفاوض، ستتم إعادة المحاولة.',
    productionHttps: 'تنبيه: في الإنتاج استخدم HTTPS حتى تعمل الكاميرا والميكروفون على الهواتف والشبكات الخارجية.',
    direct: 'STUN / Public',
    relay: 'TURN / Relay',
    waiting: 'غير متصل',
    checking: 'جاري فحص المسار',
    temporaryDisconnect: 'انقطع مؤقتاً',
    failedRetry: 'فشل — إعادة محاولة',
    endedByPeer: 'أنهى الطرف الآخر الاتصال',
    audio: 'صوت',
    yourMessages: 'أنت',
    download: 'تحميل',
    file: 'ملف',
    image: 'صورة',
    language: 'اللغة',
    arabic: 'العربية',
    english: 'English',
    czech: 'Čeština',
    lobbyHelp: 'أنشئ غرفة أو أدخل رمز غرفة موجودة. يمكن استخدام الدردشة والملفات والصوتيات داخل الغرفة.',
    dragDrop: 'يمكنك أيضاً سحب الملفات وإفلاتها هنا.',
    notificationsEnable: 'تفعيل الإشعارات',
    notificationsOn: 'الإشعارات مفعلة',
    notificationsDenied: 'الإشعارات محظورة من المتصفح.',
    notificationsSecure: 'يجب استخدام HTTPS لتفعيل إشعارات الخلفية.',
    notificationTitle: 'رسالة جديدة',
    downloadChat: 'تحميل سجل الدردشة',
    chatDownloaded: 'تم تحميل سجل الدردشة.',
    chatDownloadEmpty: 'لا توجد رسائل محفوظة للتحميل.',
    incomingFile: 'ملف جديد',
    callTab: 'مكالمة', chatTab: 'دردشة', home: 'الرئيسية', discover: 'اكتشف', create: 'إنشاء', messagesNav: 'الرسائل', profile: 'الحساب', stories: 'القصص', storiesHint: 'لحظات سريعة من أصدقائك', yourStory: 'قصتك', viewAll: 'عرض الكل', editProfile: 'تعديل', quickCall: 'مكالمة فيديو', quickShare: 'مشاركة', quickLive: 'بث مباشر', premiumTag: 'LUTSA PREMIUM', socialTagline: 'تواصل • اتصل • شارك', liveNow: 'مباشر الآن · عام', feedText: 'تحدث مع أصدقائك أينما كانوا. شارك رابط الغرفة وابدأ فورًا.', like: 'إعجاب', comment: 'تعليق', share: 'مشاركة',
  },
  en: {},
  cs: {}
};

I18N.en = {
  ...I18N.ar,
  appName: 'Lutsa vidcall', title: 'Video Calls Across Different Networks',
  subtitle: 'Video and audio calls with a chat room, images, files and voice messages. Designed for Wi‑Fi and 4G/5G with WebRTC and STUN/TURN.',
  yourName: 'Your name', namePlaceholder: 'Example: Ahmed', createRoom: 'Create New Room', joinRoom: 'Join a Room',
  roomCode: 'Room code', roomPlaceholder: 'Example: A1B2C3D4', enter: 'Join', ready: 'Ready',
  security: '🔒 Do not share the room code publicly. In production, use HTTPS and short-lived TURN credentials.', room: 'Room',
  waitingPeer: 'Waiting for the other participant…', otherParty: 'Other participant', you: 'You', voice: '🎙️ Audio', noAudio: '🔇 No audio',
  mic: '🎙️ Microphone', micOff: '🔇 Microphone muted', camera: '📷 Camera', cameraOff: '🚫 Camera off', shareScreen: '🖥️ Share screen',
  stopShare: '🛑 Stop sharing', devices: '⚙️ Devices', reconnect: '🔄 Reconnect', copyLink: '🔗 Copy link', hangup: '📞 End',
  devicePanel: 'Device selection', camera: 'Camera', microphone: 'Microphone', speaker: 'Speaker',
  deviceNote: 'Speaker selection depends on browser/device support. Camera and microphone can be changed during the call.',
  connectionStatus: 'Connection status', ice: 'ICE', path: 'Path', turnSession: 'Session TURN', turnPreparing: 'Preparing TURN…', turnReady: 'TURN ready', turnUnavailable: 'TURN unavailable — direct connection will still be used', videoQuality: 'Video quality', bitrate: 'Bitrate',
  turnHint: 'A correctly configured TURN server is important when the network blocks direct connectivity.', chatRoom: '💬 Chat Room',
  typeMessage: 'Type a message…', send: 'Send', attach: '📎 File / Image', audioMessage: '🎙️ Send voice message', stopRecording: '⏹️ Stop recording',
  recording: 'Recording', uploadPreparing: 'Preparing file…', uploading: 'Uploading file…', uploaded: 'File sent.', maxFile: 'Maximum file size is {size} MB.',
  fileType: 'This file type is not allowed.', uploadFailed: 'Failed to upload file.', fileRequired: 'Choose a file first.',
  audioFailed: 'Could not record audio. Allow microphone access.', audioSent: 'Voice message sent.', audioRecording: 'New voice message',
  noBrowserRecord: 'Audio recording is not supported by this browser.', callConnected: 'Call connected.', preparing: 'Creating connection…',
  joined: 'Joined. Waiting for connection…', foundPeer: 'Other participant found. Starting call…', roomCreated: 'Room {room} created.',
  shareRoom: 'Room created. Send the link to the other participant.', mediaPreparing: 'Preparing camera and microphone…',
  permission: 'Could not access camera/microphone. Allow permission and try again.', https: 'To connect from another device, publish the site over HTTPS. localhost works without HTTPS.',
  roomFull: 'Room is full (2 participants only).', cannotJoin: 'Could not join the room.', invalidRoom: 'Enter a room code', remoteLeft: 'The other participant left the room.',
  leftHint: 'The other participant left. You can share the link again.', remoteHangup: 'The other participant ended the call.', signalingDown: 'Signaling disconnected',
  serverRestored: 'Server connection restored.', remoteTyping: '{name} is typing…', autoplay: 'Click the remote video to enable audio if autoplay is blocked.',
  screenUnsupported: 'Screen sharing is not supported in this browser.', screenOn: 'Screen sharing is active.', cameraBack: 'Camera restored to the call.',
  cameraChanged: 'Camera changed.', micChanged: 'Microphone changed.', micUnsupported: 'Could not change microphone.', cameraUnsupported: 'Could not change camera.',
  speakerChanged: 'Speaker changed.', speakerUnsupported: 'Speaker selection is not supported in this browser.', copied: 'Room link copied. Send it to the other participant.',
  copyPrompt: 'Copy the room link:', reconnecting: 'Rebuilding connection path…', disconnected: 'Server connection temporarily lost…',
  unexpected: 'Temporary negotiation conflict. Retrying…', productionHttps: 'Notice: use HTTPS in production so camera/microphone work on phones and external networks.',
  direct: 'STUN / Public', relay: 'TURN / Relay', waiting: 'Disconnected', checking: 'Checking path', temporaryDisconnect: 'Temporarily disconnected',
  failedRetry: 'Failed — retrying', endedByPeer: 'The other participant ended the connection', audio: 'Audio', yourMessages: 'You', download: 'Download',
  file: 'File', image: 'Image', language: 'Language', arabic: 'العربية', english: 'English', czech: 'Čeština',
  lobbyHelp: 'Create a room or enter an existing code. Chat, files and voice messages are available inside the room.', dragDrop: 'You can also drag and drop files here.', notificationsEnable: 'Enable notifications', notificationsOn: 'Notifications enabled', notificationsDenied: 'Notifications are blocked by the browser.', notificationsSecure: 'HTTPS is required for background notifications.', notificationTitle: 'New message', downloadChat: 'Download chat history', chatDownloaded: 'Chat history downloaded.', chatDownloadEmpty: 'There are no saved messages to download.', incomingFile: 'New file'
};

I18N.en.home='Home'; I18N.en.discover='Discover'; I18N.en.create='Create'; I18N.en.messagesNav='Messages'; I18N.en.profile='Profile'; I18N.en.stories='Stories'; I18N.en.storiesHint='Quick moments from your people'; I18N.en.yourStory='Your story'; I18N.en.viewAll='View all'; I18N.en.editProfile='Edit'; I18N.en.quickCall='Video call'; I18N.en.quickShare='Share'; I18N.en.quickLive='Go live'; I18N.en.premiumTag='LUTSA PREMIUM'; I18N.en.socialTagline='Connect • Call • Share'; I18N.en.liveNow='Live now · Public'; I18N.en.feedText='Talk with friends wherever they are. Share a room link and start instantly.'; I18N.en.like='Like'; I18N.en.comment='Comment'; I18N.en.share='Share';

I18N.cs = {
  ...I18N.en,
  title: 'Videohovory přes různé sítě', subtitle: 'Videohovory a audiohovory s chatovací místností, obrázky, soubory a hlasovými zprávami. Určeno pro Wi‑Fi a 4G/5G pomocí WebRTC a STUN/TURN.',
  yourName: 'Vaše jméno', namePlaceholder: 'Například: Ahmed', createRoom: 'Vytvořit novou místnost', joinRoom: 'Připojit se k místnosti', roomCode: 'Kód místnosti',
  roomPlaceholder: 'Například: A1B2C3D4', enter: 'Připojit', ready: 'Připraveno', security: '🔒 Kód místnosti nesdílejte veřejně. V produkci používejte HTTPS a krátkodobé TURN údaje.',
  room: 'Místnost', waitingPeer: 'Čekání na druhého účastníka…', otherParty: 'Druhý účastník', you: 'Vy', voice: '🎙️ Zvuk', noAudio: '🔇 Bez zvuku',
  mic: '🎙️ Mikrofon', micOff: '🔇 Mikrofon ztlumen', camera: '📷 Kamera', cameraOff: '🚫 Kamera vypnuta', shareScreen: '🖥️ Sdílet obrazovku', stopShare: '🛑 Ukončit sdílení',
  devices: '⚙️ Zařízení', reconnect: '🔄 Znovu připojit', copyLink: '🔗 Kopírovat odkaz', hangup: '📞 Ukončit', devicePanel: 'Výběr zařízení', camera: 'Kamera', microphone: 'Mikrofon', speaker: 'Reproduktor',
  deviceNote: 'Výběr reproduktoru závisí na podpoře prohlížeče a zařízení. Kameru a mikrofon lze měnit během hovoru.', connectionStatus: 'Stav připojení', path: 'Trasa', videoQuality: 'Kvalita videa', bitrate: 'Datový tok',
  turnHint: 'Správně nastavený TURN server je důležitý, když síť blokuje přímé spojení.', turnSession: 'TURN relace', turnPreparing: 'Příprava TURN…', turnReady: 'TURN připraven', turnUnavailable: 'TURN není dostupný — přímé spojení bude stále použito', chatRoom: '💬 Chatovací místnost', typeMessage: 'Napište zprávu…', send: 'Odeslat', attach: '📎 Soubor / Obrázek', audioMessage: '🎙️ Odeslat hlasovou zprávu', stopRecording: '⏹️ Zastavit nahrávání', recording: 'Nahrávání',
  uploadPreparing: 'Příprava souboru…', uploading: 'Nahrávání souboru…', uploaded: 'Soubor odeslán.', maxFile: 'Maximální velikost souboru je {size} MB.', fileType: 'Tento typ souboru není povolen.', uploadFailed: 'Soubor se nepodařilo nahrát.', fileRequired: 'Nejprve vyberte soubor.',
  audioFailed: 'Zvuk se nepodařilo nahrát. Povolte přístup k mikrofonu.', audioSent: 'Hlasová zpráva odeslána.', audioRecording: 'Nová hlasová zpráva', noBrowserRecord: 'Nahrávání zvuku tento prohlížeč nepodporuje.', callConnected: 'Hovor je připojen.', preparing: 'Vytváření spojení…',
  joined: 'Připojeno. Čekání na spojení…', foundPeer: 'Druhý účastník nalezen. Spouštění hovoru…', roomCreated: 'Místnost {room} byla vytvořena.', shareRoom: 'Místnost vytvořena. Pošlete odkaz druhému účastníkovi.', mediaPreparing: 'Příprava kamery a mikrofonu…',
  permission: 'Nelze získat přístup ke kameře/mikrofonu. Povolte oprávnění a zkuste to znovu.', https: 'Pro připojení z jiného zařízení publikujte web přes HTTPS. localhost funguje bez HTTPS.', roomFull: 'Místnost je plná (pouze 2 účastníci).', cannotJoin: 'Do místnosti se nepodařilo připojit.', invalidRoom: 'Zadejte kód místnosti',
  remoteLeft: 'Druhý účastník opustil místnost', leftHint: 'Druhý účastník odešel. Odkaz můžete sdílet znovu.', remoteHangup: 'Druhý účastník ukončil hovor.', signalingDown: 'Signalizace odpojena', serverRestored: 'Připojení k serveru obnoveno.', remoteTyping: '{name} píše…',
  autoplay: 'Klikněte na vzdálené video pro zapnutí zvuku, pokud je automatické přehrávání blokováno.', screenUnsupported: 'Sdílení obrazovky není v tomto prohlížeči podporováno.', screenOn: 'Sdílení obrazovky je aktivní.', cameraBack: 'Kamera byla vrácena do hovoru.', cameraChanged: 'Kamera změněna.', micChanged: 'Mikrofon změněn.', micUnsupported: 'Mikrofon se nepodařilo změnit.', cameraUnsupported: 'Kameru se nepodařilo změnit.', speakerChanged: 'Reproduktor změněn.', speakerUnsupported: 'Výběr reproduktoru není v tomto prohlížeči podporován.', copied: 'Odkaz na místnost byl zkopírován. Pošlete jej druhému účastníkovi.', copyPrompt: 'Zkopírujte odkaz na místnost:', reconnecting: 'Obnovování spojení…', disconnected: 'Připojení k serveru bylo dočasně ztraceno…', unexpected: 'Dočasný konflikt vyjednávání. Opakování…', productionHttps: 'Upozornění: v produkci používejte HTTPS, aby kamera/mikrofon fungovaly na telefonech a externích sítích.', direct: 'STUN / Public', relay: 'TURN / Relay', waiting: 'Odpojeno', checking: 'Kontrola trasy', temporaryDisconnect: 'Dočasně odpojeno', failedRetry: 'Selhalo — opakování', endedByPeer: 'Druhý účastník ukončil spojení', audio: 'Zvuk', yourMessages: 'Vy', download: 'Stáhnout', file: 'Soubor', image: 'Obrázek', language: 'Jazyk', arabic: 'العربية', english: 'English', czech: 'Čeština', lobbyHelp: 'Vytvořte místnost nebo zadejte existující kód. V místnosti jsou dostupné chat, soubory a hlasové zprávy.', dragDrop: 'Soubory můžete také přetáhnout sem.'
};

I18N.cs.home='Domů'; I18N.cs.discover='Objevovat'; I18N.cs.create='Vytvořit'; I18N.cs.messagesNav='Zprávy'; I18N.cs.profile='Profil'; I18N.cs.stories='Příběhy'; I18N.cs.storiesHint='Krátké okamžiky od vašich lidí'; I18N.cs.yourStory='Váš příběh'; I18N.cs.viewAll='Zobrazit vše'; I18N.cs.editProfile='Upravit'; I18N.cs.quickCall='Videohovor'; I18N.cs.quickShare='Sdílet'; I18N.cs.quickLive='Vysílat živě'; I18N.cs.premiumTag='LUTSA PREMIUM'; I18N.cs.socialTagline='Spojuj. Volej. Sdílej.'; I18N.cs.liveNow='Živě · Veřejné'; I18N.cs.feedText='Mluvte s přáteli, ať jsou kdekoli. Sdílejte odkaz na místnost a začněte hned.'; I18N.cs.like='To se mi líbí'; I18N.cs.comment='Komentář'; I18N.cs.share='Sdílet';

function t(key, vars = {}) {
  let text = I18N[currentLang]?.[key] ?? I18N.en[key] ?? key;
  for (const [name, value] of Object.entries(vars)) text = text.replaceAll(`{${name}}`, String(value));
  return text;
}

function applyLanguage(lang) {
  currentLang = ['ar', 'en', 'cs'].includes(lang) ? lang : 'ar';
  localStorage.setItem('lutsavidcall_lang', currentLang);
  document.documentElement.lang = currentLang;
  document.documentElement.dir = currentLang === 'ar' ? 'rtl' : 'ltr';
  document.querySelectorAll('[data-i18n]').forEach(el => {
    el.textContent = t(el.dataset.i18n);
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    el.placeholder = t(el.dataset.i18nPlaceholder);
  });
  if (languageSelect) languageSelect.value = currentLang;
  if (recordAudioBtn && !mediaRecorder) recordAudioBtn.textContent = t('audioMessage');
  $('screenBtn').textContent = screenTrack ? t('stopShare') : t('shareScreen');
  $('micBtn').textContent = audioTrack?.enabled === false ? t('micOff') : t('mic');
  $('cameraBtn').textContent = cameraTrack?.enabled === false ? t('cameraOff') : t('camera');
  if (!remoteSocketId) remotePlaceholder.textContent = t('waitingPeer');
  if (notificationsBtn) { notificationsBtn.title = t('notificationsEnable'); notificationsBtn.setAttribute('aria-label', t('notificationsEnable')); }
  if (downloadChatBtn) { downloadChatBtn.title = t('downloadChat'); downloadChatBtn.setAttribute('aria-label', t('downloadChat')); }
}

function setStatus(text) { statusEl.textContent = text; }
function setNetwork(text, kind = '') { networkState.textContent = text; networkDot.className = `dot ${kind}`; }
function formatDuration(ms) { const total = Math.max(0, Math.floor(ms / 1000)); return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`; }
function formatMessageTime(ts) { return new Date(ts).toLocaleTimeString(currentLang === 'ar' ? 'ar-EG' : currentLang === 'cs' ? 'cs-CZ' : 'en-US', { hour: '2-digit', minute: '2-digit' }); }
function formatBytes(bytes) { if (!bytes) return '0 B'; const units = ['B','KB','MB','GB']; const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1); return `${(bytes / (1024 ** i)).toFixed(i ? 1 : 0)} ${units[i]}`; }
function isSecureContextRequired() { return location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1'; }

async function loadConfig() {
  const res = await fetch('/api/config', { cache: 'no-store' });
  if (!res.ok) throw new Error('CONFIG_FAILED');
  config = await res.json();
}

function setIceServers(iceServers) {
  const incoming = Array.isArray(iceServers) ? iceServers.filter(item => item && item.urls) : [];
  const current = Array.isArray(config.iceServers) ? config.iceServers : [];
  const seen = new Set();
  config.iceServers = [...current, ...incoming].filter(item => {
    const urls = Array.isArray(item.urls) ? item.urls.join('|') : String(item.urls || '');
    const key = `${urls}|${item.username || ''}`;
    if (!urls || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

async function applyTurnSession(turn, { restart = true } = {}) {
  if (!turn) return;
  if (Array.isArray(turn.iceServers)) setIceServers(turn.iceServers);
  if (turn.status === 'ready' && Array.isArray(turn.iceServers) && turn.iceServers.length) {
    turnReady = true;
    if (turnStateEl) turnStateEl.textContent = t('turnReady');
    if (pc) {
      try {
        const connected = ['connected', 'completed'].includes(pc.iceConnectionState);
        pc.setConfiguration({ ...pc.getConfiguration(), iceServers: config.iceServers });
        if (restart && !connected && remoteSocketId) {
          scheduleIceRestart(t('reconnecting'));
        }
      } catch (error) {
        console.warn('[TURN CONFIG]', error);
      }
    }
    return;
  }
  if (turn.status === 'preparing' || turn.status === 'creating') {
    turnReady = false;
    if (turnStateEl) turnStateEl.textContent = t('turnPreparing');
  } else if (turn.status === 'error' || turn.status === 'disabled') {
    turnReady = false;
    if (turnStateEl) turnStateEl.textContent = t('turnUnavailable');
  }
}

async function ensureLocalMedia(constraints = null) {
  if (localStream && !constraints) return localStream;
  if (localStream) { localStream.getTracks().forEach(t => t.stop()); localStream = null; }
  localStream = await navigator.mediaDevices.getUserMedia(constraints || {
    audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
    video: { width: { ideal: 1280, min: 640 }, height: { ideal: 720, min: 360 }, frameRate: { ideal: 30, max: 30 } }
  });
  audioTrack = localStream.getAudioTracks()[0] || null;
  cameraTrack = localStream.getVideoTracks()[0] || null;
  localVideo.srcObject = localStream;
  await localVideo.play().catch(() => {});
  localLabel.textContent = localName;
  applyLanguage(currentLang);
  return localStream;
}
function resetMediaReferences() { audioTrack = localStream?.getAudioTracks?.()[0] || null; cameraTrack = localStream?.getVideoTracks?.()[0] || null; }

function closePeer(keepLocal = true) {
  if (statsHandle) clearInterval(statsHandle);
  statsHandle = null;
  if (pc) {
    pc.ontrack = null; pc.onicecandidate = null; pc.onconnectionstatechange = null; pc.oniceconnectionstatechange = null;
    pc.onsignalingstatechange = null; pc.onnegotiationneeded = null; pc.onicecandidateerror = null; pc.close(); pc = null;
  }
  remoteSocketId = null; remoteStream = null; remoteVideo.srcObject = null; remotePlaceholder.classList.remove('hidden'); remotePlaceholder.textContent = t('waitingPeer');
  candidateTypeEl.textContent = '—'; qualityState.textContent = '—'; bitrateState.textContent = '—'; iceStateEl.textContent = 'new'; if (turnStateEl) turnStateEl.textContent = '—'; turnReady = false; setNetwork(t('waiting'));
  if (!keepLocal && localStream) { localStream.getTracks().forEach(t => t.stop()); localStream = null; }
}

function attachPeerEvents() {
  pc.ontrack = async event => {
    if (!remoteStream) remoteStream = new MediaStream();
    const tracks = event.streams?.[0]?.getTracks?.() || [event.track];
    for (const track of tracks) if (!remoteStream.getTracks().some(t => t.id === track.id)) remoteStream.addTrack(track);
    remoteVideo.srcObject = remoteStream;
    remotePlaceholder.classList.add('hidden');
    $('remoteAudioBadge').textContent = remoteStream.getAudioTracks().length ? t('voice') : t('noAudio');
    try { await remoteVideo.play(); } catch { setStatus(t('autoplay')); }
  };
  pc.onicecandidate = event => socket.emit('ice-candidate', { candidate: event.candidate ? event.candidate.toJSON() : null });
  pc.onicecandidateerror = e => console.warn('[ICE ERROR]', e.url, e.errorCode, e.errorText);
  pc.oniceconnectionstatechange = () => {
    if (!pc) return;
    const state = pc.iceConnectionState; iceStateEl.textContent = state;
    if (state === 'connected' || state === 'completed') { setNetwork(t('callConnected'), 'ok'); reconnectAttempt = 0; }
    else if (state === 'checking') setNetwork(t('checking'), 'warn');
    else if (state === 'failed') { setNetwork(t('failedRetry'), 'bad'); scheduleIceRestart(t('failedRetry')); }
    else if (state === 'disconnected') { setNetwork(t('temporaryDisconnect'), 'warn'); scheduleIceRestart(t('temporaryDisconnect')); }
  };
  pc.onconnectionstatechange = () => { if (pc?.connectionState === 'connected') setStatus(t('callConnected')); if (pc?.connectionState === 'failed') scheduleIceRestart(t('failedRetry')); };
  pc.onsignalingstatechange = () => {};
  pc.onnegotiationneeded = async () => {
    if (!pc || makingOffer || !remoteSocketId || !isPolite) return;
    try { makingOffer = true; const offer = await pc.createOffer(); if (pc.signalingState !== 'stable') return; await pc.setLocalDescription(offer); socket.emit('renegotiate-offer', { description: pc.localDescription }); }
    catch (err) { console.error('[RENEGOTIATION]', err); } finally { makingOffer = false; }
  };
}

async function createPeer() {
  closePeer(true);
  pc = new RTCPeerConnection({ iceServers: config.iceServers || [], iceTransportPolicy: 'all', bundlePolicy: 'max-bundle', rtcpMuxPolicy: 'require' });
  remoteStream = new MediaStream(); remoteVideo.srcObject = remoteStream;
  for (const track of localStream.getTracks()) pc.addTrack(track, localStream);
  attachPeerEvents(); startStatsLoop();
}
async function flushRemoteCandidates() { if (!pc?.remoteDescription) return; const items = remoteCandidateQueue.splice(0); for (const item of items) { try { await pc.addIceCandidate(item); } catch {} } }
async function startCallAsCaller() {
  if (!pc || !remoteSocketId) return;
  try { makingOffer = true; const offer = await pc.createOffer(); await pc.setLocalDescription(offer); socket.emit('offer', { description: pc.localDescription }); setStatus(t('preparing')); }
  catch (err) { setStatus(err?.message || t('unexpected')); } finally { makingOffer = false; }
}

async function joinRoom(roomId) {
  currentRoom = String(roomId || '').trim().toUpperCase(); localName = String(displayNameEl.value || 'Guest').trim() || 'Guest';
  if (!currentRoom) return setStatus(t('invalidRoom'));
  if (!navigator.mediaDevices?.getUserMedia) return setStatus(t('permission'));
  if (!isSecureContextRequired()) setStatus(t('https'));
  setStatus(t('mediaPreparing'));
  try { await ensureLocalMedia(); await loadConfig(); } catch { return setStatus(t('permission')); }

  socket.emit('join-room', { roomId: currentRoom, displayName: localName }, async result => {
    if (!result?.ok) return setStatus(result?.error === 'ROOM_FULL' ? t('roomFull') : t('cannotJoin'));
    await applyTurnSession(result.turn, { restart: false });
    lobby.classList.add('hidden'); call.classList.remove('hidden'); roomLabel.textContent = currentRoom; localLabel.textContent = localName;
    callStartedAt = Date.now(); if (timerHandle) clearInterval(timerHandle); timerHandle = setInterval(() => $('callTimer').textContent = formatDuration(Date.now() - callStartedAt), 1000);
    history.replaceState(null, '', `/?room=${encodeURIComponent(currentRoom)}`); remoteCandidateQueue = []; isPolite = !result.isCaller;
    messagesEl.innerHTML = ''; setUnreadCount(0); (result.history || []).forEach(msg => addMessage(msg, { notify: false }));
    document.title = I18N[currentLang]?.appName || 'Lutsa vidcall';
    if (pushSubscription) await syncPushSubscription();
    await createPeer();
    if (result.hasPeer) {
      remoteSocketId = result.peer?.socketId || 'peer'; remoteLabel.textContent = result.peer?.displayName || t('otherParty');
      setStatus(result.isCaller ? t('foundPeer') : t('joined')); if (result.isCaller) await startCallAsCaller();
    } else { remoteLabel.textContent = t('otherParty'); setStatus(t('shareRoom')); }
  });
}

function scheduleIceRestart(reason = '') {
  if (pendingRestart || !pc || !remoteSocketId) return; pendingRestart = true; reconnectAttempt += 1;
  const delay = Math.min(800 * reconnectAttempt, 4000);
  setTimeout(async () => { pendingRestart = false; if (!pc || !remoteSocketId) return; try { pc.restartIce(); makingOffer = true; const offer = await pc.createOffer({ iceRestart: true }); await pc.setLocalDescription(offer); socket.emit('offer', { description: pc.localDescription, iceRestart: true }); setStatus(reason || t('reconnecting')); } catch {} finally { makingOffer = false; } }, delay);
}

async function handleOffer(description, renegotiate = false) {
  if (!pc || !description) return;
  const offerCollision = makingOffer || pc.signalingState !== 'stable'; ignoreOffer = !isPolite && offerCollision; if (ignoreOffer) return;
  try { await pc.setRemoteDescription(description); await flushRemoteCandidates(); const answer = await pc.createAnswer(); await pc.setLocalDescription(answer); socket.emit(renegotiate ? 'renegotiate-answer' : 'answer', { description: pc.localDescription }); }
  catch (err) { if (pc.signalingState !== 'closed') setStatus(t('unexpected')); }
}
async function replaceVideoTrack(newTrack) { if (!pc || !newTrack) return; const sender = pc.getSenders().find(s => s.track?.kind === 'video'); if (sender) await sender.replaceTrack(newTrack); }

async function startScreenShare() {
  if (!navigator.mediaDevices?.getDisplayMedia) return setStatus(t('screenUnsupported'));
  try { screenStream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: { ideal: 15, max: 30 } }, audio: false }); screenTrack = screenStream.getVideoTracks()[0]; await replaceVideoTrack(screenTrack); localVideo.srcObject = screenStream; $('screenBtn').textContent = t('stopShare'); screenTrack.addEventListener('ended', stopScreenShare, { once: true }); setStatus(t('screenOn')); }
  catch (err) { if (err?.name !== 'NotAllowedError') console.warn('[SCREEN]', err); }
}
async function stopScreenShare() { if (!screenTrack) return; screenTrack.stop(); screenTrack = null; screenStream?.getTracks?.().forEach(t => t.stop()); screenStream = null; resetMediaReferences(); if (cameraTrack) await replaceVideoTrack(cameraTrack); localVideo.srcObject = localStream; $('screenBtn').textContent = t('shareScreen'); setStatus(t('cameraBack')); }

async function refreshDevices() {
  if (!navigator.mediaDevices?.enumerateDevices) return;
  const devices = await navigator.mediaDevices.enumerateDevices();
  const fills = [['cameraSelect', devices.filter(d => d.kind === 'videoinput'), t('camera')], ['micSelect', devices.filter(d => d.kind === 'audioinput'), t('microphone')], ['speakerSelect', devices.filter(d => d.kind === 'audiooutput'), t('speaker')]];
  for (const [id, items, label] of fills) { const el = $(id); if (!el) continue; const old = el.value; el.innerHTML = ''; items.forEach((d, i) => { const option = document.createElement('option'); option.value = d.deviceId; option.textContent = d.label || `${label} ${i + 1}`; el.appendChild(option); }); if ([...el.options].some(o => o.value === old)) el.value = old; }
}
async function switchCamera(deviceId) {
  if (!deviceId || !localStream) return;
  try {
    const next = await navigator.mediaDevices.getUserMedia({
      video: {
        deviceId: { exact: deviceId },
        width: { ideal: 1280 },
        height: { ideal: 720 }
      }
    });
    const nextTrack = next.getVideoTracks()[0];
    const oldTrack = localStream.getVideoTracks()[0];
    await replaceVideoTrack(nextTrack);
    if (oldTrack) { localStream.removeTrack(oldTrack); oldTrack.stop(); }
    localStream.addTrack(nextTrack);
    cameraTrack = nextTrack;
    if (!screenTrack) localVideo.srcObject = localStream;
    setStatus(t('cameraChanged'));
    await refreshDevices();
  } catch (err) {
    console.error(err);
    setStatus(t('cameraUnsupported'));
  }
}

async function switchMicrophone(deviceId) {
  if (!deviceId || !localStream) return;
  try {
    const next = await navigator.mediaDevices.getUserMedia({
      audio: {
        deviceId: { exact: deviceId },
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true
      }
    });
    const nextTrack = next.getAudioTracks()[0];
    const sender = pc?.getSenders?.().find(s => s.track?.kind === 'audio');
    if (sender) await sender.replaceTrack(nextTrack);
    const oldTrack = localStream.getAudioTracks()[0];
    if (oldTrack) { localStream.removeTrack(oldTrack); oldTrack.stop(); }
    localStream.addTrack(nextTrack);
    audioTrack = nextTrack;
    setStatus(t('micChanged'));
    await refreshDevices();
  } catch (err) {
    console.error(err);
    setStatus(t('micUnsupported'));
  }
}
async function setOutputDevice(deviceId) {
  if (!deviceId || !remoteVideo.setSinkId) return setStatus(t('speakerUnsupported'));
  try { await remoteVideo.setSinkId(deviceId); setStatus(t('speakerChanged')); } catch {}
}

async function collectStats() {
  if (!pc || pc.connectionState === 'closed') return;
  try { const stats = await pc.getStats(); let selectedPair = null; let inboundVideo = null; stats.forEach(r => { if (r.type === 'candidate-pair' && r.state === 'succeeded' && (r.nominated || r.selected)) selectedPair = r; if (r.type === 'inbound-rtp' && (r.kind === 'video' || r.mediaType === 'video')) inboundVideo = r; }); if (!selectedPair) stats.forEach(r => { if (r.type === 'candidate-pair' && r.state === 'succeeded' && !selectedPair) selectedPair = r; }); if (selectedPair) { const local = stats.get(selectedPair.localCandidateId); const remote = stats.get(selectedPair.remoteCandidateId); const type = local?.candidateType || remote?.candidateType; candidateTypeEl.textContent = type === 'relay' ? t('relay') : type === 'srflx' ? t('direct') : (type || '—'); } if (inboundVideo) { const fps = Math.round(inboundVideo.framesPerSecond || 0); const width = inboundVideo.frameWidth || 0; const height = inboundVideo.frameHeight || 0; qualityState.textContent = width && height ? `${width}×${height} • ${fps}fps` : '—'; const bytes = inboundVideo.bytesReceived || 0; const now = performance.now(); if (lastStatsAt) { const mbps = ((bytes - lastBytes) * 8 / (now - lastStatsAt)) / 1000; bitrateState.textContent = Number.isFinite(mbps) ? `${mbps.toFixed(1)} Mbps` : '—'; } lastBytes = bytes; lastStatsAt = now; } } catch {}
}
function startStatsLoop() { if (statsHandle) clearInterval(statsHandle); lastBytes = 0; lastStatsAt = 0; statsHandle = setInterval(collectStats, 2500); }

function endCallToLobby(message = null) {
  socket.emit('hangup'); if (timerHandle) clearInterval(timerHandle); timerHandle = null; if (screenTrack) stopScreenShare(); closePeer(false); call.classList.add('hidden'); lobby.classList.remove('hidden'); $('callTimer').textContent = '00:00'; setStatus(message || t('ready')); history.replaceState(null, '', '/'); currentRoom = ''; messagesEl.innerHTML = '';
}

function setUnreadCount(count) {
  unreadCount = Math.max(0, Number(count) || 0);
  if (!unreadBadge) return;
  unreadBadge.textContent = unreadCount > 99 ? '99+' : String(unreadCount);
  unreadBadge.classList.toggle('hidden', unreadCount === 0);
  const mobileUnreadBadge = $('mobileUnreadBadge');
  if (mobileUnreadBadge) {
    mobileUnreadBadge.textContent = unreadCount > 99 ? '99+' : String(unreadCount);
    mobileUnreadBadge.classList.toggle('hidden', unreadCount === 0);
  }
}
function markChatRead() { setUnreadCount(0); }
function showToast(title, text) {
  if (!toastContainer) return;
  const el = document.createElement('div'); el.className = 'toast';
  const strong = document.createElement('strong'); strong.textContent = title;
  const small = document.createElement('small'); small.textContent = text || '';
  el.append(strong, small); toastContainer.appendChild(el);
  setTimeout(() => { el.classList.add('hide'); setTimeout(() => el.remove(), 260); }, 5000);
}
function playProfessionalMessageSound() {
  try {
    audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
    if (audioContext.state === 'suspended') audioContext.resume().catch(() => {});
    const now = audioContext.currentTime;
    const master = audioContext.createGain(); master.gain.setValueAtTime(0.0001, now); master.gain.exponentialRampToValueAtTime(0.085, now + 0.015); master.gain.exponentialRampToValueAtTime(0.0001, now + 0.65); master.connect(audioContext.destination);
    [659.25, 783.99, 987.77].forEach((freq, i) => { const osc = audioContext.createOscillator(); const gain = audioContext.createGain(); osc.type = 'sine'; osc.frequency.value = freq; const start = now + i * 0.08; gain.gain.setValueAtTime(0.0001, start); gain.gain.exponentialRampToValueAtTime(0.42, start + 0.02); gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.28); osc.connect(gain).connect(master); osc.start(start); osc.stop(start + 0.3); });
  } catch {}
}
function messagePreview(msg) {
  if (msg?.kind === 'file') {
    if (String(msg.file?.type || '').startsWith('image/')) return `🖼️ ${t('image')}`;
    if (String(msg.file?.type || '').startsWith('audio/')) return `🎙️ ${t('audio')}`;
    return `📎 ${msg.file?.name || t('file')}`;
  }
  return String(msg?.text || t('notificationTitle')).slice(0, 120);
}
function notifyIncomingMessage(msg) {
  if (!msg || msg.senderSocketId === socket.id) return;
  if (msg.id && msg.id === lastNotifiedMessageId) return;
  lastNotifiedMessageId = msg.id || '';
  setUnreadCount(unreadCount + 1);
  playProfessionalMessageSound();
  showToast(msg.senderName || t('otherParty'), messagePreview(msg));
  if (document.title) document.title = `(${unreadCount}) ${t('notificationTitle')} • ${I18N[currentLang]?.appName || 'CrossCall'}`;
}
async function initExistingPushSubscription() {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) return;
  try {
    pushRegistration ||= await navigator.serviceWorker.register('/sw.js', { scope: '/' });
    if (Notification.permission === 'granted') pushSubscription = await pushRegistration.pushManager.getSubscription();
  } catch {}
}
async function enablePushNotifications() {
  if (!('Notification' in window) || !('serviceWorker' in navigator) || !('PushManager' in window)) return setStatus(t('notificationsDenied'));
  if (!isSecureContextRequired()) return setStatus(t('notificationsSecure'));
  try {
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') return setStatus(t('notificationsDenied'));
    pushRegistration ||= await navigator.serviceWorker.register('/sw.js', { scope: '/' });
    const key = await fetch('/api/push/public-key', { cache: 'no-store' }).then(r => r.json());
    if (!key?.publicKey) throw new Error('PUSH_KEY_MISSING');
    const applicationServerKey = Uint8Array.from(atob(key.publicKey.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0));
    pushSubscription = await pushRegistration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey });
    await syncPushSubscription(true);
    notificationReady = true;
    notificationsBtn.textContent = '✅'; notificationsBtn.title = t('notificationsOn');
    setStatus(t('notificationsOn'));
  } catch (error) { console.error('[PUSH ENABLE]', error); setStatus(t('notificationsDenied')); }
}
async function syncPushSubscription(force = false) {
  if (!pushSubscription || !currentRoom) return;
  const payload = { roomId: currentRoom, socketId: socket.id, displayName: localName, lang: currentLang, subscription: pushSubscription.toJSON() };
  await fetch('/api/push/subscribe', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }).then(r => { if (!r.ok) throw new Error('SUBSCRIBE_FAILED'); }).catch(() => {});
  socket.emit('push-subscription-socket', { endpoint: pushSubscription.endpoint, visible: !document.hidden });
}
async function updatePushVisibility() {
  if (!pushSubscription) return;
  socket.emit('push-visibility', { endpoint: pushSubscription.endpoint, visible: !document.hidden });
  await syncPushSubscription(false);
}
async function downloadChatHistory() {
  if (!currentRoom) return;
  try {
    const res = await fetch('/api/chat-history/download', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ roomId: currentRoom, socketId: socket.id }) });
    const data = await res.json(); if (!res.ok || !data.ok) throw new Error(data.error || 'DOWNLOAD_FAILED');
    if (!data.history?.length) return setStatus(t('chatDownloadEmpty'));
    const lines = data.history.map(m => `[${formatMessageTime(m.timestamp)}] ${m.senderName || 'Guest'}: ${messagePreview(m)}`);
    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `chat-${currentRoom}-${new Date().toISOString().slice(0,10)}.txt`; a.click(); URL.revokeObjectURL(a.href);
    setStatus(t('chatDownloaded'));
  } catch (error) { console.error('[CHAT DOWNLOAD]', error); setStatus(t('uploadFailed')); }
}

function addMessage(msg, { notify = false } = {}) {
  if (!msg || !messagesEl) return;
  const el = document.createElement('div'); const mine = msg.senderSocketId === socket.id; el.className = `message ${mine ? 'mine' : ''}`;
  const name = document.createElement('div'); name.className = 'message-name'; name.textContent = mine ? t('yourMessages') : (msg.senderName || t('otherParty'));
  const body = document.createElement('div'); body.className = 'message-content';
  if (msg.kind === 'file' && msg.file) {
    const type = String(msg.file.type || '');
    if (type.startsWith('image/')) {
      const image = document.createElement('img'); image.className = 'chat-image'; image.src = msg.file.url; image.alt = msg.file.name; image.loading = 'lazy'; image.addEventListener('click', () => window.open(msg.file.url, '_blank', 'noopener')); body.appendChild(image);
    } else if (type.startsWith('audio/')) {
      const audio = document.createElement('audio'); audio.className = 'chat-audio'; audio.controls = true; audio.preload = 'metadata'; audio.src = msg.file.url; body.appendChild(audio);
    }
    if (msg.text) { const caption = document.createElement('div'); caption.className = 'message-text'; caption.textContent = msg.text; body.appendChild(caption); }
    const link = document.createElement('a'); link.className = 'file-link'; link.href = msg.file.url; link.target = '_blank'; link.rel = 'noopener'; link.download = msg.file.name; link.textContent = `⬇️ ${msg.file.name} • ${formatBytes(msg.file.size)}`; body.appendChild(link);
  } else {
    const text = document.createElement('div'); text.className = 'message-text'; text.textContent = msg.text || ''; body.appendChild(text);
  }
  const time = document.createElement('div'); time.className = 'message-time'; time.textContent = formatMessageTime(msg.timestamp || Date.now()); el.append(name, body, time); messagesEl.appendChild(el); messagesEl.scrollTop = messagesEl.scrollHeight;
  if (notify) notifyIncomingMessage(msg);
}

async function uploadFile(file) {
  if (!file || !currentRoom) return;
  const max = Number(config.maxFileSize || 25 * 1024 * 1024);
  if (file.size > max) return setStatus(t('maxFile', { size: Math.round(max / 1024 / 1024) }));
  setStatus(t('uploading'));
  const form = new FormData(); form.append('file', file);
  try {
    const res = await fetch('/api/upload', { method: 'POST', headers: { 'X-Room-Id': currentRoom, 'X-Socket-Id': socket.id }, body: form });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.ok) throw new Error(data.error || 'UPLOAD_FAILED');
    setStatus(t('uploaded'));
  } catch (err) { console.error('[UPLOAD]', err); setStatus(err.message === 'FILE_TOO_LARGE' ? t('maxFile', { size: Math.round(max / 1024 / 1024) }) : err.message === 'FILE_TYPE_NOT_ALLOWED' ? t('fileType') : t('uploadFailed')); }
}

function chooseRecordingMime() {
  if (!window.MediaRecorder) return '';
  const types = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'];
  return types.find(type => MediaRecorder.isTypeSupported?.(type)) || '';
}
async function toggleAudioRecording() {
  if (mediaRecorder && mediaRecorder.state === 'recording') { mediaRecorder.stop(); return; }
  if (!window.MediaRecorder) return setStatus(t('noBrowserRecord'));
  if (!audioTrack) { try { await ensureLocalMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: false }); } catch { return setStatus(t('audioFailed')); } }
  const mimeType = chooseRecordingMime();
  try {
    audioChunks = []; const recordStream = new MediaStream([audioTrack]); mediaRecorder = new MediaRecorder(recordStream, mimeType ? { mimeType } : undefined); recordingStartedAt = Date.now();
    mediaRecorder.ondataavailable = e => { if (e.data?.size) audioChunks.push(e.data); };
    mediaRecorder.onstop = async () => { clearInterval(recordingTimer); recordAudioBtn.textContent = t('audioMessage'); const blob = new Blob(audioChunks, { type: mediaRecorder.mimeType || 'audio/webm' }); if (!blob.size) return; let ext = blob.type.includes('ogg') ? 'ogg' : blob.type.includes('mp4') ? 'mp4' : 'webm'; const file = new File([blob], `voice_${Date.now()}.${ext}`, { type: blob.type || 'audio/webm' }); await uploadFile(file); mediaRecorder = null; };
    mediaRecorder.start(250); recordAudioBtn.classList.add('recording'); recordingTimer = setInterval(() => { recordAudioBtn.textContent = `${t('stopRecording')} ${formatDuration(Date.now() - recordingStartedAt)}`; }, 500); setStatus(t('recording'));
  } catch (err) { console.error('[RECORD]', err); setStatus(t('audioFailed')); mediaRecorder = null; }
}

socket.on('turn-ready', async data => {
  await applyTurnSession(data, { restart: true });
});
socket.on('turn-error', data => {
  applyTurnSession(data, { restart: false });
  console.warn('[TURN] session credential unavailable');
});

socket.on('peer-joined', async info => { remoteSocketId = info.socketId || 'peer'; remoteLabel.textContent = info.displayName || t('otherParty'); setStatus(t('foundPeer')); if (pc) await startCallAsCaller(); });
socket.on('peer-ready', info => { remoteSocketId = info.socketId || 'peer'; remoteLabel.textContent = info.displayName || t('otherParty'); });
socket.on('offer', msg => handleOffer(msg.description, false));
socket.on('renegotiate-offer', msg => handleOffer(msg.description, true));
socket.on('answer', async msg => { if (!pc || !msg?.description) return; try { await pc.setRemoteDescription(msg.description); await flushRemoteCandidates(); } catch {} });
socket.on('renegotiate-answer', async msg => { if (!pc || !msg?.description) return; try { await pc.setRemoteDescription(msg.description); await flushRemoteCandidates(); } catch {} });
socket.on('ice-candidate', async msg => { if (!pc || !msg?.candidate) return; if (!pc.remoteDescription) remoteCandidateQueue.push(msg.candidate); else { try { await pc.addIceCandidate(msg.candidate); } catch {} } });
socket.on('peer-left', () => { remoteSocketId = null; remoteLabel.textContent = t('otherParty'); remotePlaceholder.textContent = t('remoteLeft'); remotePlaceholder.classList.remove('hidden'); if (pc) closePeer(true); setStatus(t('leftHint')); });
socket.on('remote-hangup', () => { remotePlaceholder.textContent = t('remoteHangup'); remotePlaceholder.classList.remove('hidden'); setNetwork(t('endedByPeer'), 'warn'); setStatus(t('remoteHangup')); });
socket.on('peer-reconnect-request', () => scheduleIceRestart(t('reconnect')));
socket.on('chat-message', msg => addMessage(msg, { notify: true }));
socket.on('chat-typing', data => { typingIndicator.textContent = data?.isTyping ? t('remoteTyping', { name: data.senderName || t('otherParty') }) : ''; });
socket.on('disconnect', () => { setNetwork(t('signalingDown'), 'bad'); if (!call.classList.contains('hidden')) setStatus(t('disconnected')); });
socket.on('connect', () => { if (!call.classList.contains('hidden')) setStatus(t('serverRestored')); });

$('createBtn').onclick = () => socket.emit('create-room', {}, result => { if (!result?.ok) return setStatus(t('cannotJoin')); roomInput.value = result.roomId; $('joinBox').classList.remove('hidden'); setStatus(t('roomCreated', { room: result.roomId })); joinRoom(result.roomId); });
$('joinBtn').onclick = () => $('joinBox').classList.toggle('hidden');
$('joinExistingBtn').onclick = () => joinRoom(roomInput.value);
roomInput.addEventListener('keydown', e => { if (e.key === 'Enter') joinRoom(roomInput.value); });
displayNameEl.value = localStorage.getItem('crosscall_name') || '';
displayNameEl.addEventListener('input', () => localStorage.setItem('crosscall_name', displayNameEl.value));
document.addEventListener('pointerdown', () => { try { audioContext ||= new (window.AudioContext || window.webkitAudioContext)(); if (audioContext.state === 'suspended') audioContext.resume(); } catch {} }, { once: true });
$('hangupBtn').onclick = () => endCallToLobby();
$('micBtn').onclick = () => { resetMediaReferences(); if (!audioTrack) return; audioTrack.enabled = !audioTrack.enabled; $('micBtn').textContent = audioTrack.enabled ? t('mic') : t('micOff'); };
$('cameraBtn').onclick = () => { resetMediaReferences(); if (!cameraTrack) return; cameraTrack.enabled = !cameraTrack.enabled; $('cameraBtn').textContent = cameraTrack.enabled ? t('camera') : t('cameraOff'); };
$('screenBtn').onclick = () => screenTrack ? stopScreenShare() : startScreenShare();
$('deviceBtn').onclick = async () => { $('devicePanel').classList.toggle('hidden'); if (!$('devicePanel').classList.contains('hidden')) await refreshDevices(); };
$('cameraSelect').onchange = e => switchCamera(e.target.value);
$('micSelect').onchange = e => switchMicrophone(e.target.value);
$('speakerSelect').onchange = e => setOutputDevice(e.target.value);
$('restartBtn').onclick = () => { socket.emit('request-reconnect'); scheduleIceRestart(t('reconnecting')); };
$('shareBtn').onclick = async () => { const url = `${location.origin}/?room=${encodeURIComponent(currentRoom)}`; try { await navigator.clipboard.writeText(url); setStatus(t('copied')); } catch { window.prompt(t('copyPrompt'), url); } };
$('chatForm').addEventListener('submit', e => { e.preventDefault(); const text = chatInput.value.trim(); if (!text || !currentRoom) return; socket.emit('chat-message', { text }); chatInput.value = ''; socket.emit('chat-typing', { isTyping: false }); });
chatInput.addEventListener('input', () => { socket.emit('chat-typing', { isTyping: Boolean(chatInput.value.trim()) }); clearTimeout(typingTimer); typingTimer = setTimeout(() => socket.emit('chat-typing', { isTyping: false }), 900); });
fileInput.addEventListener('change', async () => { const files = [...fileInput.files].slice(0, 8); for (const file of files) await uploadFile(file); fileInput.value = ''; });
uploadBtn.onclick = () => fileInput.click();
recordAudioBtn.onclick = toggleAudioRecording;
const dropzone = $('dropzone');
['dragenter','dragover'].forEach(type => dropzone?.addEventListener(type, e => { e.preventDefault(); dropzone.classList.add('drag'); }));
['dragleave','drop'].forEach(type => dropzone?.addEventListener(type, e => { e.preventDefault(); dropzone.classList.remove('drag'); }));
dropzone?.addEventListener('drop', async e => { const files = [...e.dataTransfer.files].slice(0, 8); for (const file of files) await uploadFile(file); });
notificationsBtn?.addEventListener('click', enablePushNotifications);
downloadChatBtn?.addEventListener('click', downloadChatHistory);
messagesEl?.addEventListener('click', markChatRead);
messagesEl?.addEventListener('focus', markChatRead);
document.addEventListener('visibilitychange', () => { updatePushVisibility(); if (!document.hidden) { markChatRead(); document.title = I18N[currentLang]?.appName || 'Lutsa vidcall'; } });
languageSelect?.addEventListener('change', e => applyLanguage(e.target.value));
remoteVideo.addEventListener('click', () => remoteVideo.play().catch(() => {}));
async function fullscreen(el) { try { if (document.fullscreenElement) await document.exitFullscreen(); else await el.requestFullscreen(); } catch {} }
$('remoteFullBtn').onclick = () => fullscreen(remoteVideo); $('localFullBtn').onclick = () => fullscreen(localVideo);

displayNameEl.value = localStorage.getItem('crosscall_name') || '';
applyLanguage(currentLang);
initExistingPushSubscription();

(async () => {
  try { const cfg = await fetch('/api/config').then(r => r.json()); $('appName').textContent = cfg.appName || t('appName'); config = cfg; if (turnStateEl) turnStateEl.textContent = cfg.turnMode === 'metered-dynamic' ? t('turnPreparing') : (cfg.hasTurn ? t('turnReady') : t('turnUnavailable')); } catch {}
  const room = new URLSearchParams(location.search).get('room');
  if (room) { roomInput.value = room; $('joinBox').classList.remove('hidden'); setStatus(t('shareRoom')); }
  if (location.protocol !== 'https:' && !['localhost','127.0.0.1'].includes(location.hostname)) setStatus(t('productionHttps'));
})();
